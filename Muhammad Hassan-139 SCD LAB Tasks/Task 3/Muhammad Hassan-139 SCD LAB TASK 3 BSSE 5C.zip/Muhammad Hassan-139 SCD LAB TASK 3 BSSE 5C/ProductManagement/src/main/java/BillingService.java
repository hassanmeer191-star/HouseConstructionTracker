public class BillingService {
public double calculateSubtotal(Product product) {
return product.getPrice() * product.getQuantity();
}

public double calculateDiscount(Product product) {

double subtotal = calculateSubtotal(product);

if (subtotal >= 10000) {
return subtotal * 0.10;
}

return 0;
}

public double calculateFinalTotal(Product product) {

double subtotal = calculateSubtotal(product);
double discount = calculateDiscount(product);

return subtotal - discount;
}
}
