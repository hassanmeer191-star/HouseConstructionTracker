public class Main {
public static void main(String[] args) {
BillingService billing = new BillingService();
Product product1 = new Product("Keyboard", 5000, 1);
displayBill(product1, billing);
Product product2 = new Product("Keyboard", 5000, 2);
displayBill(product2, billing);
Product product3 = new Product("Keyboard", 5000, 3);
displayBill(product3, billing);
}

public static void displayBill(Product product, BillingService billing) {
double subtotal = billing.calculateSubtotal(product);
double discount = billing.calculateDiscount(product);
double finalTotal = billing.calculateFinalTotal(product);
System.out.println("Product: " + product.getProductName());
System.out.println("Subtotal: " + subtotal);
System.out.println("Discount: " + discount);
System.out.println("Final Bill: " + finalTotal);
}
}
