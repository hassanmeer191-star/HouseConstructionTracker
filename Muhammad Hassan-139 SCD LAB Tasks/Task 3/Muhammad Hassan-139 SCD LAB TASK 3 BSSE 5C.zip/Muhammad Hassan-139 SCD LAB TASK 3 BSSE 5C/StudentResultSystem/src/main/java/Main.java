public class Main {
public static void main(String[] args) {
Student s1 = new Student("Ali Khan", 101);
Student s2 = new Student("Ahmed", 102);
Student s3 = new Student("Bilal", 103);
ResultCalculator calculator = new ResultCalculator();
double a1 = calculator.calculateAverage(78, 85, 91);
String gr1 = calculator.calculateGrade(a1);
boolean p1 = calculator.isPassed(a1);
System.out.println("Student: " + s1.getName());
System.out.println("Roll No: " + s1.getRollNo());
System.out.printf("Average: %.2f%n", a1);
System.out.println("Grade: " + gr1);
System.out.println("Status: " + (p1 ? "Pass" : "Fail"));
double a2 = calculator.calculateAverage(8, 5, 9);
String gr2 = calculator.calculateGrade(a1);
boolean p2 = calculator.isPassed(a1);
System.out.println("Student: " + s2.getName());
System.out.println("Roll No: " + s2.getRollNo());
System.out.printf("Average: %.2f%n", a2);
System.out.println("Grade: " + gr2);
System.out.println("Status: " + (p2 ? "Pass" : "Fail"));
double a3 = calculator.calculateAverage(88, 65, 91);
String gr3 = calculator.calculateGrade(a3);
boolean p3 = calculator.isPassed(a3);
System.out.println("Student: " + s3.getName());
System.out.println("Roll No: " + s3.getRollNo());
System.out.printf("Average: %.2f%n", a3);
System.out.println("Grade: " + gr3);
System.out.println("Status: " + (p3 ? "Pass" : "Fail"));
}
}