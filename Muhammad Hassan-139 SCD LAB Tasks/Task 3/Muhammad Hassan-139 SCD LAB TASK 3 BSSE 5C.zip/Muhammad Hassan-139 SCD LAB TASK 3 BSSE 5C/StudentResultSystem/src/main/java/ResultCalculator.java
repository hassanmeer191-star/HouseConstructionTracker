public class ResultCalculator {
public double calculateAverage(double m1, double m2, double m3) {
return (m1 + m2 + m3) / 3.0;
}
public String calculateGrade(double average) {
if (average >= 80)
return "A";
else if (average >= 70)
return "B";
else if (average >= 60)
return "C";
else if (average >= 50)
return "D";
else
return "F";
}
public boolean isPassed(double average) {
return average >= 50;
}
}
