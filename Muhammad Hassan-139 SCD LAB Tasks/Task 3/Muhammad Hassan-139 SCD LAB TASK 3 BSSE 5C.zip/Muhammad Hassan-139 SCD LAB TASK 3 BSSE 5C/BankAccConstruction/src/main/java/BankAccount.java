public class BankAccount {

private String accountNumber;
private String accountHolderName;
private double balance;

// Constructor
public BankAccount(String accountNumber, String accountHolderName, double balance) {
this.accountNumber = accountNumber;
this.accountHolderName = accountHolderName;
this.balance = balance;
}

// Deposit money
public void deposit(double amount) {
if (amount <= 0) {
System.out.println("Deposit rejected.");
return;
}

balance = balance + amount;
System.out.println("Deposit successful: " + amount);
}

// Withdraw money
public void withdraw(double amount) {
if (amount <= 0) {
System.out.println("Withdrawal rejected.");
return;
}

if (amount > balance) {
System.out.println("Withdrawal rejected: Insufficient balance.");
return;
}

balance = balance - amount;
System.out.println("Withdrawal successful: " + amount);
}

// Return current balance
public double getBalance() {
return balance;
}
}
