public class Main {

public static void main(String[] args) {

BankAccount account = new BankAccount(
"ACC1001",
"Ahmed",
5000
);

System.out.println("Initial Balance: " + account.getBalance());

// Operation 1: Deposit
account.deposit(2000);
System.out.println("Balance: " + account.getBalance());

// Operation 2: Withdraw
account.withdraw(1000);
System.out.println("Balance: " + account.getBalance());

// Operation 3: Invalid withdrawal
account.withdraw(10000);
System.out.println("Balance: " + account.getBalance());

// Operation 4: Invalid deposit
account.deposit(-500);
System.out.println("Balance: " + account.getBalance());
}
}
