public class Main {
public static void main(String[] args) {
ResultCalculator calculator = new ResultCalculator();
Student[] students = {
new Student(101, "Samad",
new double[]{85, 78, 90, 88, 80}),
new Student(102, "Hassan",
new double[]{45, 50, 40, 48, 42}),
new Student(103, "Sara",
new double[]{92, 88, 95, 90, 94}),
new Student(104, "Fatima",
new double[]{65, 70, 62, 68, 66}),
new Student(105, "Usman",
new double[]{35, 40, 45, 38, 42})
};
double totalAverage = 0;
int passed = 0;
int failed = 0;
Student highestStudent = students[0];
Student lowestStudent = students[0];
System.out.println("CLASS RESULT SUMMARY");
for (Student student : students) {
double average = calculator.calculateAverage(student);
String grade = calculator.calculateGrade(average);
String status = calculator.getStatus(average);
System.out.println(
student.getRollNumber() + "  " +
student.getName() + "  " +
String.format("%.2f", average) + "  " +
grade + "  " +
status
);
totalAverage += average;
if (status.equals("PASS")) {
passed++;
} else {
failed++;
}

if (average > calculator.calculateAverage(highestStudent)) {
highestStudent = student;
}

if (average < calculator.calculateAverage(lowestStudent)) {
lowestStudent = student;
}
}
double classAverage = totalAverage / students.length;

System.out.println("---------------------------------------------");

System.out.println("Student with Highest Average:");
System.out.println(
highestStudent.getRollNumber() + " - " +
highestStudent.getName() + " - " +
String.format("%.2f",
calculator.calculateAverage(highestStudent))
);
System.out.println();
System.out.println("Student with Lowest Average:");
System.out.println(
lowestStudent.getRollNumber() + " - " +
lowestStudent.getName() + " - " +
String.format("%.2f",
calculator.calculateAverage(lowestStudent))
);
System.out.println();
System.out.println("Overall Class Average: " +
String.format("%.2f", classAverage));
System.out.println("Passed Students: " + passed);
System.out.println("Failed Students: " + failed);
}
}
