public class ResultCalculator {
public boolean isValidMark(double mark) {
return mark >= 0 && mark <= 100;
}

public double calculateTotal(Student student) {
double total = 0;
for (double mark : student.getMarks()) {
total += mark;
}

return total;
}

public double calculateAverage(Student student) {
return calculateTotal(student) / student.getMarks().length;
}
public String calculateGrade(double average) {
if (average >= 80) {
return "A";
} else if (average >= 70) {
return "B";
} else if (average >= 60) {
return "C";
} else if (average >= 50) {
return "D";
} else {
return "F";
}
}

public String getStatus(double average) {
if (average >= 50) {
return "PASS";
} else {
return "FAIL";
}
}
}
