public class Main {
public static void main(String[] args) {
ResultCalculator calculator = new ResultCalculator();
Student[] students = {
new Student(101, "Abdul Samad", new double[]{85, 78, 90, 88, 80}),
new Student(102, "Hassan", new double[]{45, 50, 40, 48, 42}),
new Student(103, "Sara", new double[]{100, 100, 100, 100, 100}),
new Student(104, "Fatima", new double[]{60, 65, 70, 62, 68}),
new Student(105, "Usman", new double[]{49, 50, 48, 51, 47})
};
displaySummary(students, calculator);
}
public static void displaySummary(
Student[] students, ResultCalculator calculator) {
int passed = 0;
int failed = 0;
double totalAverage = 0;
Student highest = students[0];
Student lowest = students[0];
System.out.println("CLASS RESULT SUMMARY");
for (Student student : students) {
if (!calculator.areMarksValid(student)) {
System.out.println(student.getName() + ": Invalid marks");
continue;
}
double average = calculator.calculateAverage(student);
String grade = calculator.calculateGrade(average);
String status = calculator.getStatus(average);

System.out.println(student.getRollNumber() + " "
+ student.getName() + " "
+ String.format("%.2f", average) + " "
+ grade + " " + status);
totalAverage += average;
if (status.equals("PASS")) {
passed++;
} else {
failed++;
}
if (average > calculator.calculateAverage(highest)) {
highest = student;
}
if (average < calculator.calculateAverage(lowest)) {
lowest = student;
}
}
displayClassStatistics(
students.length,
totalAverage,
passed,
failed,
highest,
lowest,
calculator
);
}
public static void displayClassStatistics(
int totalStudents,
double totalAverage,
int passed,
int failed,
Student highest,
Student lowest,
ResultCalculator calculator) {
double classAverage = totalAverage / totalStudents;
System.out.println("Highest: " + highest.getName()
+ " - "
+ calculator.calculateAverage(highest));

System.out.println("Lowest: " + lowest.getName()
+ " - "
+ calculator.calculateAverage(lowest));

System.out.println("Class Average: "
+ String.format("%.2f", classAverage));

System.out.println("Passed: " + passed);
System.out.println("Failed: " + failed);
}
}
